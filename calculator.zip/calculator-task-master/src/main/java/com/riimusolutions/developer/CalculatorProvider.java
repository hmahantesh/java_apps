package com.riimusolutions.developer;

/**
 * Provides an instance of a {@link Calculator}.
 */
public class CalculatorProvider {

	private CalculatorProvider() {
		// cannot be instantiated
	}

	static Calculator getCalculator() {
		// TODO Task 1: get rid of this exception and construct a proper calculator
		throw new UnsupportedOperationException("Providing calculators is not yet supported");
	}
}
